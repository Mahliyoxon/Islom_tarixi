package com.example.hikoya;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class entery extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTitle( "Kirish" );
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entery);
    }
}