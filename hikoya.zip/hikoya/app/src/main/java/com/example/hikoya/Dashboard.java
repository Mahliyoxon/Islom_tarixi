package com.example.hikoya;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

public class Dashboard extends AppCompatActivity {
    ListView lvprogram;
    String[] lvTitle = {"Kirish", "Ikkiga ajralgan ummatning birlashishi"};
    int[] numImage = {R.drawable.one, R.drawable.two};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_dashboard );
        lvprogram = findViewById( R.id.lvprogram );
        System.out.println("Mahliyo");
        ProgramAdapter programAdapter = new ProgramAdapter( this, lvTitle, numImage );
        lvprogram.setAdapter( programAdapter );
        System.out.println("Mahliyo");
        lvprogram.setOnItemClickListener( new AdapterView.OnItemClickListener() {

            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                TextView txtname =(TextView)view.findViewById( R.id.textView1 );
                int pos = position;
                String name = txtname.getText().toString();
                if (pos == 0){

                        Intent intent = new Intent(view.getContext(),entery.class);
                           startActivity( intent );


                }
               else {
                    Intent intent1 = new Intent(view.getContext(),PassWay.class);

               }
            }
        } );

    }
}