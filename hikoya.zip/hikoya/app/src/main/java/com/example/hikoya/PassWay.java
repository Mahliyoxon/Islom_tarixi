package com.example.hikoya;

public class PassWay {
}
